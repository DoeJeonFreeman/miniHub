# Installation

1.  First, copy the theme-directory into ../public/themes/. This would result in a directory-path to application.css like:
../public/themes/<themename>/stylesheets/application.css

2. You now may need to restart Redmine so that it shows the newly installed theme in the list of available themes.

3. Go to "Administration -> Settings" -> "Display" and select your newly created theme in the "Theme" drop-down list. Save your settings.

Reference to: http://www.redmine.org/projects/redmine/wiki/Themes#Installing-a-theme